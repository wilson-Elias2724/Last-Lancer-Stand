import pygame
import math
class Tower():
    def __init__(self, pos, image, range):
        self.range = range #range da torre
        self.target = None 
        self.damage = 10  
        self.attack_cooldown = 60  # ataca a cada 1 segundo, pq ta a 60 fps
        self.cooldown_timer = 0 

        #animação
        self.animations = [
            pygame.image.load("assets/towers/lancer/right_attack_1.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/right_attack_2.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/right_attack_3.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/up_attack_1.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/up_attack_2.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/up_attack_3.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/down_attack_1.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/down_attack_2.png").convert_alpha(),
            pygame.image.load("assets/towers/lancer/down_attack_3.png").convert_alpha()
              ]
        self.animations = [pygame.transform.scale(f, (230, 230)) for f in self.animations]
        self.animations = {
        "right":  self.animations[0:3],    
        "up":  self.animations[3:6],    
        "down": self.animations[6:9],
        "left": [pygame.transform.flip(f, True, False) for f in self.animations[0:3]]
        }

        self.image = self.animations["right"][-1]
        self.rect = self.image.get_rect()
        self.rect.center = pos #onde ele tá
        self.current_anim = "right"
        self.last_direction = "right"
        self.frame_index = 0
        self.animation_speed = 0.2
        self.is_attacking = False
    def attack(self):
        if self.cooldown_timer > 0:
            self.cooldown_timer -= 1
            return

        if self.target is not None:
            self.is_attacking = True
            self.frame_index = 0
            died = self.target.take_damage(self.damage)
            self.cooldown_timer = self.attack_cooldown
            if died:
                self.target = None  # mata 

    def find_target(self,enemies):
        for enemy in enemies:
            dx = enemy.rect.centerx - self.rect.centerx #distâncias da torre até o enemy
            dy = enemy.rect.centery - self.rect.centery
            if abs(dx) > abs(dy):
                if dx > 0:
                    self.last_direction = "right"
                else:
                    self.last_direction = "left"
            else:
                if dy > 0:
                    self.last_direction = "down"
                else:
                    self.last_direction = "up"
            distance = math.hypot(dx, dy)
            if distance <= self.range:
                self.target = enemy
                return 
            #animação (de novo)
    def animate(self):
        if self.is_attacking:
            self.frame_index += self.animation_speed
            frames = self.animations[self.last_direction]
            if self.frame_index >= len(frames):
                    self.frame_index = len(frames) - 1
                    self.is_attacking = False
            self.image = frames[int(self.frame_index)]
        else:
             self.image = self.animations[self.last_direction][-1]
    
    def update(self, enemies):
        if self.target is None: #tem ninguém
            self.find_target(enemies)
        else: 
            dx = self.target.rect.centerx - self.rect.centerx
            dy = self.target.rect.centery - self.rect.centery
            distance = math.hypot(dx, dy)
            if distance > self.range:
                self.target = None  # saiu do range
        self.animate()