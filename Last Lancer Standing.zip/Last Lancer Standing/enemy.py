import pygame
import math
class Enemy():
    def __init__(self, path, image):
        self.image = image
        self.rect = self.image.get_rect()
        self.path = path
        self.target_index = 1 # próximo ponto que ele persegue
        self.rect.center = self.path[0]  # começa no primeiro ponto do caminho
        self.speed = 2
        self.health = 30
        self.frames = [ #muitas imagens
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_1.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_2.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_3.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_4.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_5.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_6.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_7.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_8.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_9.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_10.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_11.png").convert_alpha(),
    pygame.image.load("assets/enemy/chomp_frames/chomp_frame_12.png").convert_alpha(),
]          
            #animation
        self.frame_index = 0
        self.frames = [pygame.transform.scale(f, (64, 64)) for f in self.frames]
        self.animations = {
        "down":  self.frames[0:4],    
        "left":  self.frames[4:8],    
        "up": self.frames[8:12],
        "right": [pygame.transform.flip(f, True, False) for f in self.frames[4:8]]
        }
        self.direction = "left"
        self.animation_speed = 0.15

    def take_damage(self, amount):
        self.health -= amount
        if self.health <= 0:
            return True   # morreu
        return False       # vivo
    def move(self):
        if self.target_index >= len(self.path):
            return True

        target_x = self.path[self.target_index][0]
        target_y = self.path[self.target_index][1]

        dx = target_x - self.rect.centerx
        dy = target_y - self.rect.centery

    # detecta direção 
        if abs(dx) > abs(dy):          # movimento horizontal
            if dx < 0:
                self.direction = "left"
            else:
                self.direction = "right"
        else:                           # movimento vertical
            if dy < 0:
                self.direction = "up"
            else:
                self.direction = "down"

    # animação com direção
        self.frame_index += self.animation_speed
        frames = self.animations[self.direction]
        if self.frame_index >= len(frames):
            self.frame_index = 0
        self.image = frames[int(self.frame_index)]

    # movimento normal
        distance = math.hypot(dx, dy)
        if distance != 0:
            dx = dx / distance
            dy = dy / distance
        self.rect.centerx += dx * self.speed
        self.rect.centery += dy * self.speed

        if distance < 5:
            self.target_index += 1

        return False