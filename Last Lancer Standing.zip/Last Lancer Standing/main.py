import pygame
pygame.init()  
from enemy import Enemy
from tower import Tower
width, height = 900, 700 #tamanho do mapa
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("Last Lancer Standing") #nome do jogo
coins = 100          # moedas iniciais
tower_cost = 50 
clock = pygame.time.Clock()  
run = True
fps = 60
MAX_WAVES = 10
lose = False
victory = False
PATH_POINTS = [
    (800, 565),  # nasce
    (650, 565),  # esquerda
    (650, 450),  # sobe
    (470, 450),  # esquerda
    (470, 335),  # sobe
    (280, 335),  # esquerda
    (280, 220),  # sobe
    (140, 220),  # esquerda
    (140, 150),  # sobe
]

#enemigo
enemy_image = pygame.image.load("assets/enemy/chomp_frames/chomp_frame_5.png").convert_alpha() 
enemy_image = pygame.transform.scale(enemy_image, (64, 64)) 
enemy = Enemy(PATH_POINTS, enemy_image)
enemies = []
enemy_alive = True

#wave
wave = 1
enemies_to_spawn = 5
spawn_timer = 0
spawn_delay = 60

#map
image = pygame.image.load("assets/maps/map1.png").convert_alpha() 
image = pygame.transform.scale(image, (width, height)) 
reached_end = enemy.move()

#tower
tower_image = pygame.image.load("assets/towers/lancer/lancer_idle.png").convert_alpha()
tower_image = pygame.transform.scale(tower_image, (230, 230))
towers = []   

#base
base_health = 100
if reached_end:
    base_health -= 4 
font = pygame.font.SysFont(None, 36)

#gadgets
heart_icon = pygame.image.load("assets/Gadgets/heart.png").convert_alpha()
heart_icon = pygame.transform.scale(heart_icon, (100, 100))

coin_icon = pygame.image.load("assets/Gadgets/coin_fresh.png").convert_alpha()
coin_icon = pygame.transform.scale(coin_icon, (70, 70))

while run:
    if not lose and not victory:
        #waves
        spawn_timer += 1
    if enemies_to_spawn > 0 and spawn_timer >= spawn_delay:
        enemies.append(Enemy(PATH_POINTS, enemy_image))
        enemies_to_spawn -= 1
        spawn_timer = 0
    if base_health <= 0:
        lose = True
    if len(enemies) == 0 and enemies_to_spawn == 0:
        if wave >= MAX_WAVES:
            victory = True
        wave += 1
        enemies_to_spawn = 5 + wave * 2

    #events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:  
            run = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            if not lose and not victory:
                mouse_pos = pygame.mouse.get_pos()
                if coins >= tower_cost:
                    new_tower = Tower(mouse_pos, tower_image, 150)
                    towers.append(new_tower)
                    coins -= tower_cost

    #map
    screen.fill((30, 30, 40))
    screen.blit(image,(0,0)) #botar o mapa
    

    #enemy
    for e in enemies:
        screen.blit(e.image, e.rect)
    enemies_to_remove = []
    for e in enemies:
        result = e.move()
        if result:              #chegou ao fim
            base_health -= 4
            enemies_to_remove.append(e)
        elif e.health <= 0:     #morreu
            coins += 10         #ganha moedas ao matar
            enemies_to_remove.append(e)
    for e in enemies_to_remove:
        enemies.remove(e)

    #tower
    for t in towers:
        screen.blit(t.image, t.rect)
    for t in towers:
        t.update(enemies)       
        t.attack()

    #health
    screen.blit(heart_icon, (width - 150, 0))  
    health_text = font.render(f"{base_health}", True, (255, 255, 255)) 
    screen.blit(health_text, (width -75, 30))  

    #coins
    screen.blit(coin_icon, (width -135, 75))
    coin_text = font.render(f"{coins}", True, (255, 255, 255))
    screen.blit(coin_text, (width -75, 100))

    #wave
    wave_text = font.render(f"WAVE {wave}", True, (255, 255, 255))
    screen.blit(wave_text, (400,50))
    if victory:
        overlay = pygame.Surface((width, height))
        overlay.set_alpha(180)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))
        victory_text = font.render("The kingdom was saved!", True, (100,255, 0))
        screen.blit(victory_text, victory_text.get_rect(center=(width // 2, height // 2)))

    if lose:
        overlay = pygame.Surface((width, height))
        overlay.set_alpha(180)
        overlay.fill((0, 0, 0))
        screen.blit(overlay, (0, 0))
        lose_text = font.render("The kingdom has fallen", True, (200, 0, 0))
        screen.blit(lose_text, lose_text.get_rect(center=(width // 2, height // 2)))


    pygame.display.flip()   

    clock.tick(fps)  

pygame.quit()